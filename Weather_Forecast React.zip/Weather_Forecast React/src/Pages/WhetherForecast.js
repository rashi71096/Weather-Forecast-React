import React, { useState, useEffect } from 'react'
import { Row, Col, Input, InputNumber, Skeleton, PageHeader } from 'antd';
import WhetherCard from '../Components/WhetherCard';
import axios from 'axios';
import Spinner from '../Components/Spinner';
import moment from 'moment';

const { Search } = Input;

const WhetherForecast = () => {
    const [loadingInfo, setLoadingInfo] = useState(false);
    const [information, setInfo] = useState(null);
    const [days, setDays] = useState(5);
    const [city, setCity] = useState('Bangalore')

    useEffect(() => {
        getForecast();
    }, [city, days])

    const groupBy = (array, key) => {

        const modifiedArray = array.map((ele) => {
            return { ...ele, datum: moment(ele.dt_txt).format('MM/DD/YYYY') }
        })
        return modifiedArray.reduce((result, currentValue) => {
            (result[currentValue[key]] = result[currentValue[key]] || []).push(
                currentValue
            );

            return result;
        }, {});
    };

    const getForecast = () => {
        setLoadingInfo(true);
        axios.get('https://api.openweathermap.org/data/2.5/forecast', {
            params: {
                q: city,
                appid: '176bfa00e925a58a2bac323569ca1e09',
                cnt: 40,
                units:"metrics"
            }
        })
            .then((response) => {
                const groupedForecast = Object.entries(groupBy(response.data.list, 'datum'))
                console.log(groupedForecast, 'grouped')
                setInfo(groupedForecast.slice(0, days));
            })
            .catch((error) => {
                console.log(error, 'err');
            })
            .then(() => {
                setLoadingInfo(false);
            });
        return true
    }

    return (
        <div style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: loadingInfo ? 'white' : '#F5F5F5' }}>

            <div>
                <Row justify="start" style={{ padding: 16 }}>
                    <Col span={8}>
                        <PageHeader
                            style={{ fontFamily: "cursive" }}
                            title="WeathereX"
                            subTitle="Easily forecast wether"
                        />
                    </Col>
                    <Col span={8}>
                        <Search
                            placeholder="Type city"
                            allowClear
                            enterButton="Search City"
                            size="large"
                            onSearch={(text) => setCity(text)}
                        />
                    </Col>
                    <Col span={4}>
                        <InputNumber value={days} placeholder="Days" enterButton="Search City" size="large"
                            onChange={(text) => setDays(text)} />
                    </Col>
                </Row>
                {loadingInfo ? <>

                    <Skeleton style={{ margin: 21 }} avatar paragraph={{ rows: 4 }} />
                    <Spinner />
                </> :

                    <>
                        <div style={{ color: 'red' }}>
                            Search results for '{city}'
                    </div>
                        <Row justify="space-around">

                            {information?.map((whether) => (
                                <Col span={8}>
                                    <WhetherCard whether={whether} />
                                </Col>
                            ))}
                        </Row>
                    </>
                }
            </div>
        </div>
    );
}

export default WhetherForecast;