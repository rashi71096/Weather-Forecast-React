import React from 'react'
import ClickCounter from '../Components/ClickCounter';
import HoverCounter from '../Components/HoverCounter';

export default function About() {
    return (
        <div>
           <ClickCounter/>
           <HoverCounter/>
        </div>
    )
}
