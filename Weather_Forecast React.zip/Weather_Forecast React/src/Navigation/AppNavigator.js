import React from "react";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import { Breadcrumb } from 'antd'
import WeatherForecast from '../Pages/WhetherForecast';
import About from '../Pages/About';
import ContactUs from '../Pages/ContactUs';

export default function App() {
    return (
        <Router>
            <div>
                <Breadcrumb>
                    <Breadcrumb.Item>
                        <Link to="/">Home</Link>
                    </Breadcrumb.Item>
                    <Breadcrumb.Item>
                        <Link to="/about">About</Link>
                    </Breadcrumb.Item>
                    <Breadcrumb.Item>
                        <Link to="/contact">Contact</Link>
                    </Breadcrumb.Item>
                </Breadcrumb>

                {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
                <Switch>
                    <Route path="/about" component={About}>
                        <About />
                    </Route>
                    <Route path="/contact" component={ContactUs}>
                        <ContactUs />
                    </Route>
                    <Route path="/" component={WeatherForecast}>
                        <WeatherForecast />
                    </Route>
                </Switch>
            </div>
        </Router>
    );
}