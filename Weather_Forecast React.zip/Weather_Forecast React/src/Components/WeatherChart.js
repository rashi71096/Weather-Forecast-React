import React, { useRef, useEffect } from 'react';
import Chart from "chart.js";
import moment from 'moment';

const WeatherChart = ({ records, day }) => {
  const chartRef = useRef(null);

  const getMinTemp = () => {
    const minTemp = records.map(({ main }) => ( main.temp_min - 273.15));
    return minTemp;
  }

  const getMaxTemp = () => {
    const maxTemp = records.map(({ main }) => ( main.temp_max - 273.15));
    return maxTemp;
  }


  const getLabel = () => {
    const labels = records.map(({ dt_txt }) => moment(dt_txt).format('hh:mm'));
    return labels;
  }


  useEffect(() => {
    const myChartRef = chartRef.current.getContext("2d");

    new Chart(myChartRef, {
      type: "line",
      data: {
        //Bring in data
        labels: getLabel(),
        datasets: [
          {
            label: "Minimum Temperature",
            data: getMinTemp(),
            // fill: true,
            // backgroundColor: 'green',
            borderColor: "green"
          },
          {
            label: "Maximum Temperature",
            data: getMaxTemp(),
            // fill: true,
            // backgroundColor: 'red',
            borderColor: "red"
          },

        ]
      },
      options: {
        legend: {
          labels: {
            // This more specific font property overrides the global property
            fontColor: 'black',
            fontFamily: 'cursive'
          }
        }
      }

    });
  }, [getLabel, getMinTemp])

  return (


    <div style={{ alignItems: 'center', justifyContent: 'center', alignContent: 'center', paddingTop: 9 }}>
      <canvas
        id="myChart"
        ref={chartRef}
      />
      <div style={{ fontSize: 11, fontFamily: 'cursive', color: 'blue' }}>
        {day}
      </div>
    </div>

  )

};

export default WeatherChart