import React, { Component } from 'react'
import withManageIncrement from '../Containers/withManageIncrement';

class ClickCounter extends Component {
    // constructor(props) {
    //     super(props)

    //     this.state = {
    //         count: 0
    //     }
    // }

    // incrementCounter = () => {
    //     this.setState(prevState => {
    //         return ({ count: prevState.count + 1 })
    //     })
    // }

    render() {
        const {count,incrementCounter}=this.props
        return (
            <div>
                <button onClick={incrementCounter}>Click Me!</button>
            </div>
        )
    }
}

export default withManageIncrement(ClickCounter);