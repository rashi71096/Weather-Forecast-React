import React, { useState} from 'react';
import { Avatar, Typography,Row,Col } from 'antd';
import moment from 'moment';
import ReactCardFlip from 'react-card-flip';
import WeatherChart from './WeatherChart';

const { Title } = Typography;
// https://www.greeka.com/photos/greece/greece-weather/hero/greece-weather-1280.jpg
// https://www.photohdx.com/images/2015/11/dark-blue-clouds-texture.jpg
const imagestyle = {
  backgroundImage: "url(" + "https://www.photohdx.com/images/2015/11/dark-blue-clouds-texture.jpg" + ")",
  backgroundPosition: 'center',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat'
};




const WhetherCard = ({ whether }) => {
  const [show, setShow] = useState(false);
  const focusedData = whether ? whether[1][0] : null;
  const imageUrl = "http://openweathermap.org/img/wn/" + focusedData?.weather[0].icon + "@2x.png"
console.log(focusedData.main.temp,'kk')

  const mouseEventHandler = () => {
    setShow(!show)
  }

  return (
    <ReactCardFlip isFlipped={show} flipDirection="vertical">
      <div onClick={mouseEventHandler} style={{
        display: 'flex',
        margin: 16, height: 240, borderRadius: 7, boxShadow: `2px 2px 2px #9E9E9E`, shadowOpacity: 1.0, ...imagestyle
      }}>
        <div style={{
          display: 'flex', alignItems: 'flex-start', justifyContent: "flex-start", flex: 3, margin: 21,
          borderColor: 'white', borderStyle: 'dashed', borderWidth: 0, borderRightWidth: 0.1,
          flexDirection: 'column'
        }}>
          <Title style={{ color: 'white', fontFamily: 'cursive' }} level={4}>{moment(whether[0]).format('LL')}</Title>

          <Title style={{ color: 'white', fontFamily: 'cursive' }} level={1}>{moment(whether[0]).format('dddd')}</Title>
         {/* fccccc
          ff */}
            <Row justify="space-between">
      <Col flex={1} order={4} style={{color:'#FF6347',fontFamily:"cursive",fontWeight:'bold',fontSize:18}}>
          :  {Math.round(focusedData.main.temp_min-273.15)}&deg;<text style={{ color: 'white' }}>C</text>
      </Col>
      <Col flex={1} order={3}  style={{color:'white',fontFamily:"cursive"}}>
      Minimum Temperature
      </Col>
  
    </Row>
    <Row justify="space-between">
      <Col flex={1} order={4}  style={{color:'#FF6347',fontFamily:"cursive",fontWeight:'bold',fontSize:18}}>
          : {Math.round(focusedData.main.temp_max-273.15)}&deg;<text style={{ color: 'white' }}>C</text>
      </Col>
      <Col flex={1} order={3}  style={{color:'white',fontFamily:"cursive"}}>
      Maximum Temperature
      </Col>
  
    </Row>
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', flex: 2, flexDirection: 'column' }} >
          <div style={{ flex: 1 }}>
            <Avatar src={imageUrl} style={{ height: 120, width: 120 }} />
          </div>
          <div style={{ flex: 2 }}>
  <Title style={{ color: '	#FF6347', fontFamily: 'cursive' }} level={1}>
    {Math.round(focusedData.main.temp-273.15)}&deg;<text style={{ color: 'white' }}>C</text></Title>
            <text style={{ color: '#FF6347', fontFamily: 'cursive' }}>Avg. Temp</text>
          </div>
        </div>
      </div>

      <div onMouseLeave={mouseEventHandler} style={{
        borderWidth: 1, borderStyle: 'solid', borderColor: 'lightblue', backgroundColor: 'white',
        margin: 16, height: 240, borderRadius: 7, boxShadow: `2px 2px 2px lightblue`, shadowOpacity: 1.0, alignItems: 'center', justifyContent: 'center'
      }}>

        <WeatherChart records={whether[1]} day={moment(whether[0]).format('LL')} />

      </div>
    </ReactCardFlip>


  )
}

export default WhetherCard;