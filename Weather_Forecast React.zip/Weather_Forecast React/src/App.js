import './App.css';
import 'antd/dist/antd.css'
import WhetherForecast from './Pages/WhetherForecast';
import AppNavigator from './Navigation/AppNavigator';

const imagestyle = {
  backgroundImage: "url(" + "https://starkaerospace.com/wp-content/uploads/2014/06/background-world-map-1.gif" + ")",
  backgroundPosition: 'center',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat'
};

const App = () => {
  return (
    <div className="App">
      <AppNavigator/>
      {/* jjjj */}
     </div>
  );
}

export default App;
